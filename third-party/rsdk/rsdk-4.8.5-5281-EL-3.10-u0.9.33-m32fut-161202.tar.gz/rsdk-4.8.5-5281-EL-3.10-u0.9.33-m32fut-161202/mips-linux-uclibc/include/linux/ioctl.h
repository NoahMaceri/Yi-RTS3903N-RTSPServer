#ifndef _LINUX_IOCTL_H
#define _LINUX_IOCTL_H

#include <asm/ioctl.h>

#endif /* _LINUX_IOCTL_H */

